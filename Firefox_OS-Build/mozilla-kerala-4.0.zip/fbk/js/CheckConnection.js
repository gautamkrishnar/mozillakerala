﻿Main.prototype.checkConnection = function () {
    networkCondition = navigator.onLine ? true : false;
}